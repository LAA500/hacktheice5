<?php

namespace App\Cart;

use Illuminate\Support\Collection;

class CartConditionCollection extends Collection
{
    //
}
