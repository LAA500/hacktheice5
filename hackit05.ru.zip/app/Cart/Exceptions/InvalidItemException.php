<?php

namespace App\Cart\Exceptions;

use Exception;

class InvalidItemException extends Exception
{
    //
}
