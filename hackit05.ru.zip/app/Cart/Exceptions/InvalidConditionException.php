<?php

namespace App\Cart\Exceptions;

use Exception;

class InvalidConditionException extends Exception
{
    /** */
}
