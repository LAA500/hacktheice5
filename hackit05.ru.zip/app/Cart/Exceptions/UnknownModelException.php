<?php

namespace App\Cart\Exceptions;

use Exception;

class UnknownModelException extends Exception
{
    //
}
