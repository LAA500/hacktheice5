<?php

namespace App\Cart\Validators;

class CartItemValidator extends Validator
{
    //
}
