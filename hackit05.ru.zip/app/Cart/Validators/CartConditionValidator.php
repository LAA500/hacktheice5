<?php

namespace App\Cart\Validators;

class CartConditionValidator extends Validator
{
    //
}
