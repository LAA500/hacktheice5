

<?php $__env->startSection('title', 'Профиль'); ?>

<?php $__env->startPush('meta'); ?>
<meta name="theme-color" content="#fff" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="Profile">
    <div class="container">
        <div class="Profile-top mb-4">
            <div class="text-center">
                <div class="mt-3">
                    <div class="row justify-content-around">
                        <div class="col-4">
                            <div class="Profile-menu-block">
                                <a href="/profile/orders">
                                    <div class="Profile-menu-block-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="#fff"
                                            viewBox="0 0 16 16">
                                            <path
                                                d="M12.643 15C13.979 15 15 13.845 15 12.5V5H1v7.5C1 13.845 2.021 15 3.357 15zM5.5 7h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1 0-1M.8 1a.8.8 0 0 0-.8.8V3a.8.8 0 0 0 .8.8h14.4A.8.8 0 0 0 16 3V1.8a.8.8 0 0 0-.8-.8H.8z" />
                                        </svg>
                                    </div>
                                    <div class="Profile-menu-block-name">ЗАКАЗЫ</div>
                                </a>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="Profile-menu-block">
                                <a href="/cart">
                                    <div class="Profile-menu-block-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="#fff"
                                            viewBox="0 0 16 16">
                                            <path
                                                d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5M5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4m7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2m7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2" />
                                        </svg>
                                    </div>
                                    <div class="Profile-menu-block-name">КОРЗИНА</div>
                                </a>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="Profile-menu-block">
                                <a href="/profile/favorites">
                                    <div class="Profile-menu-block-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="#fff"
                                            viewBox="0 0 16 16">
                                            <path fill-rule="evenodd"
                                                d="M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314" />
                                        </svg>
                                    </div>
                                    <div class="Profile-menu-block-name">ИЗБРАННОЕ</div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="Profile-orders mb-4">
            <div>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <a class="fs-5" href="<?php echo e(route('complete', $order)); ?>">Заказ №<?php echo e($order->id); ?> от <?php echo e($order->created_at->format('d.m.Y, H:i')); ?></a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="mt-4">
            <div>
                <div>
                    <a href="<?php echo e(route('logout')); ?>" class="text-danger">Выйти из профиля</a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\hackit05.ru\resources\views/public/profile/orders.blade.php ENDPATH**/ ?>