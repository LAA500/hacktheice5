

<?php $__env->startSection('title', 'Оформление заказа'); ?>

<?php $__env->startSection('content'); ?>
<section class="Checkout">
    <div class="container">
        <div class="SectionHeader">
            <h2 class="SectionTitle">Оформление заказа</h2>
        </div>
        <div class="SectionContent">
            <div class="row">
                <div class="col-md-4">
                    <checkout></checkout>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\hackit05.ru\resources\views/public/checkout.blade.php ENDPATH**/ ?>