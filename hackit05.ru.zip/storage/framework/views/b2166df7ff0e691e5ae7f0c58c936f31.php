

<?php $__env->startSection('content'); ?>
<div>
    <div>
        <div class="mb-3">
            <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-secondary" role="button">Создать</a>
        </div>
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Наименование</th>
                        <th>Категория</th>
                        <th>Наличие</th>
                        <th>Цена</th>
                        <th>Дата создания</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="<?php echo e(route('admin.products.edit', $product)); ?>"><?php echo e($product->name); ?></a></td>
                        <td><?php echo e($product->category->name); ?></td>
                        <td class="small <?php echo e($product->in_stock ? 'text-success' : 'text-danger'); ?>"><?php echo e($product->in_stock ? 'Есть в наличии' : 'Нет в наличии'); ?></td>
                        <td><?php echo e(price($product->price)); ?></td>
                        <td><?php echo e($product->created_at->format('d.m.Y, H:i')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\hackit05.ru\resources\views/admin/products/index.blade.php ENDPATH**/ ?>