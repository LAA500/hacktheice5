

<?php $__env->startSection('title', 'Главная'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div>
        <div class="row">
            <?php $__currentLoopData = $city->shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="Shop-card">
                    <a href="<?php echo e(route('shop', $shop)); ?>">
                        <div>
                            <div class="Shop-card-name">
                                <div><?php echo e($shop->name); ?></div>
                            </div>
                            <div class="Shop-card-address">
                                <div><?php echo e($shop->address); ?></div>
                            </div>
                            <div class="Shop-card-phone">
                                <div><?php echo e($shop->phone_format); ?></div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\hackit05.ru\resources\views/public/index.blade.php ENDPATH**/ ?>