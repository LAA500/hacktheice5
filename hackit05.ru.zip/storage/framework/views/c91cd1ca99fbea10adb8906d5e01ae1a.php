<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta name="format-detection" content="telephone=no">
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(config('app.name')); ?></title>
    <link rel="manifest" href="/manifest.webmanifest">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <?php echo app('Tightenco\Ziggy\BladeRouteGenerator')->generate(); ?>
    <?php echo $__env->yieldPushContent('meta'); ?>
</head>

<body>
    <div id="app">
        <?php echo $__env->yieldContent('header'); ?>
        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <aside>
            <?php echo $__env->yieldPushContent('modals'); ?>
        </aside>

        <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH C:\OSPanel\domains\hackit05.ru\resources\views/layouts/simple.blade.php ENDPATH**/ ?>