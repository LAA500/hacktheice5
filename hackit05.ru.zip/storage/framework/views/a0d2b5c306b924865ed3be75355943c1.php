

<?php $__env->startSection('content'); ?>
<div>
    <div>
        <div class="mb-3">
            <a href="<?php echo e(route('admin.supplies.create')); ?>" class="btn btn-secondary" role="button">Создать</a>
        </div>
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>№ поставки</th>
                        <th>Дата создания</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $supplies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="<?php echo e(route('admin.supplies.edit', $supply)); ?>"><?php echo e($supplies->number); ?></a></td>
                        
                        <td><?php echo e($supply->created_at->format('d.m.Y, H:i')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\hackit05.ru\resources\views/admin/supplies/index.blade.php ENDPATH**/ ?>