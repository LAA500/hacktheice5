

<?php $__env->startSection('title', 'Выберите роль'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="text-center">
        <div>
            <div class="mb-4">
                <div class="fs-4">Для продолжения работы с сайтом, выберите роль</div>
            </div>
            <div class="my-4">
                <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 mb-3 mx-auto">
                    <a class="btn btn-primary w-100" href="<?php echo e(route('select_role.set', $role->name)); ?>"><?php echo e($role->label); ?></a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.simple', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\hackit05.ru\resources\views/select_role.blade.php ENDPATH**/ ?>