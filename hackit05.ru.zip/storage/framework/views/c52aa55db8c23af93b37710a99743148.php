

<?php $__env->startSection('content'); ?>
<div>
    <div>
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Номер заказа</th>
                        <th>Клиент</th>
                        <th>Номер телефона</th>
                        <th>Магазин</th>
                        <th>Всего</th>
                        <th>Дата создания</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="<?php echo e(route('admin.orders.edit', $order)); ?>"><?php echo e($order->id); ?></a></td>
                        <td><?php echo e($order->name); ?></td>
                        <td><?php echo e($order->phone_format); ?></td>
                        <td><?php echo e($order->shop->name); ?></td>
                        <td><?php echo e(price($order->total)); ?></td>
                        <td><?php echo e($order->created_at->format('d.m.Y, H:i')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\hackit05.ru\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>