<?php $__env->startSection('title', 'Вход'); ?>

<?php $__env->startSection('content'); ?>
<section class="Login">
    <div class="container">
        <div class="row justify-content-center align-items-center">
            <div class="col-md-5">
                <div class="card border-0">
                    <div class="card-body">
                        <div class="mb-3 text-center">
                            <div class="mb-4">
                                <a href="/">
                                    <div class="Logo" style="background-image: url(/assets/images/logo.png?v=001);">
                                    </div>
                                </a>
                            </div>
                            <div class="fs-4 fw-bold">Добро пожаловать!</div>
                        </div>
                        <form method="POST" action="<?php echo e(route('login')); ?>" novalidate>
                            <?php echo csrf_field(); ?>
                            <div class="form-group mb-3">
                                <div class="form-floating">
                                    <input id="email" type="email" class="form-control form-control-lg" name="email"
                                        value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="Email">
                                    <label for="email">Email</label>
                                </div>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="form-control-invalid" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group mb-3">
                                <div class="form-floating">
                                    <input id="password" type="password" class="form-control" name="password" required
                                        autocomplete="current-password" placeholder="Пароль">
                                    <label for="password">Пароль</label>
                                </div>

                                <div>
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="form-control-invalid" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group mb-0">
                                <button type="submit"
                                    class="btn btn-lg btn-primary w-100 loader text-white">Войти</button>
                                <div class="text-center">
                                    <div class="mt-3">
                                        <?php if(Route::has('password.request')): ?>
                                        <a class="btn fw-bold" href="<?php echo e(route('password.request')); ?>">Забыли
                                            пароль?</a>
                                        <?php endif; ?>
                                    </div>
                                    <div class="mt-2">
                                        <?php if(Route::has('register')): ?>
                                        <a class="btn fw-bold" href="<?php echo e(route('register')); ?>">Регистрация</a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="module">
    document.querySelector("form").addEventListener("submit", function (e) {
        let button = document.querySelector('.loader');
        button.setAttribute('disabled', 'disabled');
        button.className += ' btn-loading';
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.simple', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\hackit05.ru\resources\views/auth/login.blade.php ENDPATH**/ ?>