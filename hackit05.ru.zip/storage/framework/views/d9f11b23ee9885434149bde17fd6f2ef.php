

<?php $__env->startSection('title', 'Корзина'); ?>

<?php $__env->startSection('content'); ?>
<section class="Cart">
    <div class="container">
        <div class="SectionHeader">
            <h2 class="SectionTitle">Корзина</h2>
        </div>
        <div class="SectionContent">
            <cart></cart>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\hackit05.ru\resources\views/public/cart.blade.php ENDPATH**/ ?>