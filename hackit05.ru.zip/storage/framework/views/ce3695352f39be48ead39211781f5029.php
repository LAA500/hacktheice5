

<?php $__env->startSection('title', 'Ваш заказ оформлен'); ?>

<?php $__env->startSection('content'); ?>
<section class="Complete">
    <div class="container">
        <div class="SectionContent">
            <div class="col-md-4 mx-auto">
                <div class="text-center">
                    <div class="my-4">
                        <div>
                            <div class="fs-4 text-success">Ваш заказ оформлен. Спасибо!</div>
                        </div>
                        <div class="mt-4">
                            <div>Заказ № <?php echo e($order->id); ?></div>
                            <div>от <?php echo e($order->created_at->format('d.m.Y, H:i')); ?></div>
                        </div>
                        <div class="mt-4">
                            <div>
                                <div>Состав заказа</div>
                            </div>
                            <div>
                                <div>
                                    <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div><?php echo e($product->name); ?>, <?php echo e($product->pivot->quantity); ?> шт., <?php echo e(price($product->pivot->price)); ?></div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="mt-4">
                            <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e(route('profile.orders')); ?>" class="btn btn-primary" role="button">Перейти к моим заказам</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\hackit05.ru\resources\views/public/complete.blade.php ENDPATH**/ ?>