<?php $__env->startSection('title', 'Не найдено'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="text-center">
        <div class="my-4">
            <div>
                <div class="fs-2 fw-bold">Не найдено</div>
            </div>
            <div class="mt-3">
                <a href="/" class="btn btn-primary">Вернуться на главную</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\hackit05.ru\resources\views/errors/404.blade.php ENDPATH**/ ?>