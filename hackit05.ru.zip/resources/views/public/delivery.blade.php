@extends('layouts.app')

@section('title', 'Доставка и оплата')

@section('content')
<section class="Delivery">
    
</section>
@endsection