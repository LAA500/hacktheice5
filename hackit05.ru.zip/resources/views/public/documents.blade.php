@extends('layouts.app')

@section('title', 'Документы')

@section('content')
<section class="Documents">
    
</section>
@endsection